﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using u21639672_HW06.Models;

namespace u21639672_HW06.Data
{
    public class u21639672_HW06Context : DbContext
    {
        public u21639672_HW06Context (DbContextOptions<u21639672_HW06Context> options)
            : base(options)
        {
        }

        public DbSet<u21639672_HW06.Models.Product> Product { get; set; }
    }
}
