﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace u21639672_HW06.Models
{
    public class SystemRepository
    {
        public List<Brands> GetBrands()
        {
            SystemDBContext brandDBC = new SystemDBContext();
            return brandDBC.Brands.ToList();
        }

        public List<Category> Category()
        {
            SystemDBContext categoryDBC = new SystemDBContext();
            return categoryDBC.Category.ToList();
        }

        public List<CustomerSales> CustomerSales()
        {
            SystemDBContext brandDBC = new SystemDBContext();
            return brandDBC.CustomerSales.ToList();
        }

        public List<Order> Order()
        {
            SystemDBContext brandDBC = new SystemDBContext();
            return brandDBC.Order.ToList();
        }

        public List<OrderItem> OrderItem()
        {
            SystemDBContext brandDBC = new SystemDBContext();
            return brandDBC.OrderItem.ToList();
        }

        public List<Product> Product()
        {
            SystemDBContext brandDBC = new SystemDBContext();
            return brandDBC.Product.ToList();
        }

        public List<Production> Production()
        {
            SystemDBContext brandDBC = new SystemDBContext();
            return brandDBC.Production.ToList();
        }

        public List<Staff> Staff()
        {
            SystemDBContext brandDBC = new SystemDBContext();
            return brandDBC.Staff.ToList();
        }

        public List<Store> Store()
        {
            SystemDBContext brandDBC = new SystemDBContext();
            return brandDBC.Store.ToList();
        }
    }
}
