﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace u21639672_HW06.Models
{
    public class OrderItem
    {
        public int orderId { get; set; }
        public int itemId { get; set; }
        public int productID { get; set; }
        public int quantity { get; set; }
        public double listPrice { get; set; }
        public double discount { get; set; }
    }
}
