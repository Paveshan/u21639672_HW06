﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace u21639672_HW06.Models
{
    public class Store
    {
        public int storeID { get; set; }
        public string storeName { get; set; }
        public string phone { get; set; }
        public string email { get; set; }
        public string street { get; set; }
        public string city { get; set; }
        public string state { get; set; }
        public string zipCode { get; set; }
    }
}
