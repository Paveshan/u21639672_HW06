﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace u21639672_HW06.Models
{
    public class Order
    {
        public int orderID { get; set; }
        public int customerID { get; set; }
        public int orderStatus { get; set; }
        public DateTime orderDate { get; set; }
        public DateTime requiredDate { get; set; }
        public DateTime shippedDate { get; set; }
        public int storeID { get; set; }
        public int staffID { get; set; }
    }
}
