﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace u21639672_HW06.Models
{
    public class Staff
    {
        public int staffID { get; set; }
        public string firstName { get; set; }
        public string lastName { get; set; }
        public string email { get; set; }
        public string phone { get; set; }
        public int activity { get; set; }
        public int storeID { get; set; }
        public int managerID { get; set; }
    }
}
