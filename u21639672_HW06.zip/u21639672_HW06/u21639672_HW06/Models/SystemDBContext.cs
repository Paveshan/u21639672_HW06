﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;


namespace u21639672_HW06.Models
{
    public class SystemDBContext:DbContext
    {
        public DbSet<Brands> Brands { get; set; }
        public DbSet<Category> Category { get; set; }
        public DbSet<CustomerSales> CustomerSales { get; set; }
        public DbSet<Order> Order { get; set; }
        public DbSet<OrderItem> OrderItem { get; set; }
        public DbSet<Product> Product { get; set; }
        public DbSet<Production> Production { get; set; }
        public DbSet<Staff> Staff { get; set; }
        public DbSet<Store> Store { get; set; }
    }
}
